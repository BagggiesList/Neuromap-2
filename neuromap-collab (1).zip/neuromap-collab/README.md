Schnellstart

1. Node.js (>=16) installieren
2. Projektordner entpacken und in das Verzeichnis wechseln
3. npm install
4. npm start
5. Öffne im Browser: http://localhost:3000/ und verbinde mehrere Tabs oder Freunde mit der gleichen Map-ID

Tipps:
- Jeder Beitretende erhält eine Owner-ID (socket id). Knoten werden beim Erzeugen mit owner gesetzt.
- Du kannst persistence verbessern (z. B. DB statt JSON-Dateien) oder Auth (z. B. Discord OAuth) hinzufügen.
- Für öffentliches Hosting benutze Render, Railway, Fly.io oder einen VPS. Platforms wie Vercel benötigen Anpassung, da Socket.io persistente WebSockets braucht.
