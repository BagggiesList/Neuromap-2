const socket = io();
let myId = null;
let myName = null;
let mapId = null;

// vis setup
const nodes = new vis.DataSet([]);
const edges = new vis.DataSet([]);
const container = document.getElementById('network');
const data = { nodes, edges };
const options = { interaction:{ hover:true, multiselect:true }, nodes:{ shape:'dot', size:18 }, physics:{ stabilization:true } };
const network = new vis.Network(container, data, options);

// UI
const nameInput = document.getElementById('name');
const mapInput = document.getElementById('mapId');
const joinBtn = document.getElementById('join');
const status = document.getElementById('status');
const addNodeBtn = document.getElementById('addNode');
const addEdgeBtn = document.getElementById('addEdge');
const nodetext = document.getElementById('nodetext');
const saveBtn = document.getElementById('save');
const usersDiv = document.getElementById('users');

let edgeMode = false;
let edgeFrom = null;

joinBtn.addEventListener('click', ()=>{
  myName = nameInput.value || ('User-' + Math.floor(Math.random()*1000));
  mapId = mapInput.value || 'default';
  socket.emit('join', { mapId, name: myName });
  status.textContent = 'Verbunden mit ' + mapId;
});

socket.on('init', ({ nodes: n, edges: e, myId: id, myName: mName })=>{
  myId = id; myName = mName;
  nodes.clear(); edges.clear();
  // convert maps object's values to arrays
  for(const k in n) nodes.add(n[k]);
  for(const k in e) edges.add(e[k]);
});

socket.on('node:added', node => nodes.add(node));
socket.on('node:updated', node => nodes.update(node));
socket.on('node:deleted', ({id}) => nodes.remove(id));

socket.on('edge:added', edge => edges.add(edge));
socket.on('edge:deleted', ({id}) => edges.remove(id));

socket.on('user-joined', u => {
  usersDiv.textContent = 'User online: ' + u.name + ' (+' + u.id.slice(0,4) + ')';
});
socket.on('user-left', u => {
  usersDiv.textContent = 'User left: ' + u.name;
});

addNodeBtn.addEventListener('click', ()=>{
  const text = nodetext.value || 'Neu';
  const node = { label: text, x: null, y: null };
  socket.emit('node:add', node);
  nodetext.value = '';
});

addEdgeBtn.addEventListener('click', ()=>{ edgeMode = true; alert('Klicke Quelle dann Ziel'); });

network.on('click', params =>{
  if(edgeMode){
    if(params.nodes.length===1){
      if(!edgeFrom) edgeFrom = params.nodes[0];
      else {
        const to = params.nodes[0];
        const edge = { from: edgeFrom, to };
        socket.emit('edge:add', edge);
        edgeFrom = null; edgeMode = false;
      }
    }
  }
});

network.on('dragEnd', params =>{
  if(params.nodes && params.nodes.length){
    params.nodes.forEach(id =>{
      const pos = network.getPositions([id])[id];
      socket.emit('node:update', { id, x: pos.x, y: pos.y });
    });
  }
});

saveBtn.addEventListener('click', ()=> socket.emit('save:request'));
socket.on('save:ok', ()=> alert('Map gespeichert'));
