// server.js
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*'} });

// Simple persistence folder (optional)
const DATA_DIR = path.join(__dirname, 'maps');
if(!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

// In-memory store: { mapId: { nodes: {}, edges: {} } }
const maps = {};

function loadMap(mapId){
  const file = path.join(DATA_DIR, mapId + '.json');
  if(fs.existsSync(file)){
    try{ return JSON.parse(fs.readFileSync(file)); } catch(e){ return { nodes:{}, edges:{} }; }
  }
  return { nodes:{}, edges:{} };
}
function saveMap(mapId){
  const file = path.join(DATA_DIR, mapId + '.json');
  fs.writeFileSync(file, JSON.stringify(maps[mapId], null, 2));
}

io.on('connection', socket =>{
  console.log('conn', socket.id);

  // client should emit 'join' with {mapId, name}
  socket.on('join', ({mapId, name}) =>{
    if(!mapId) mapId = 'default';
    socket.join(mapId);
    socket.data.name = name || ('User-' + socket.id.slice(0,4));
    socket.data.mapId = mapId;

    // load map if not in memory
    if(!maps[mapId]) maps[mapId] = loadMap(mapId);

    // Send current state to joining client
    socket.emit('init', { nodes: maps[mapId].nodes, edges: maps[mapId].edges, myId: socket.id, myName: socket.data.name });

    // notify others
    socket.to(mapId).emit('user-joined', { id: socket.id, name: socket.data.name });
  });

  // Node operations: add/update/delete
  socket.on('node:add', node =>{
    const mapId = socket.data.mapId || 'default';
    const id = node.id || uuidv4();
    const owner = socket.id;
    const payload = Object.assign({}, node, { id, owner });
    maps[mapId].nodes[id] = payload;
    io.to(mapId).emit('node:added', payload);
    saveMap(mapId);
  });

  socket.on('node:update', update =>{
    const mapId = socket.data.mapId || 'default';
    if(!maps[mapId].nodes[update.id]) return;
    maps[mapId].nodes[update.id] = Object.assign({}, maps[mapId].nodes[update.id], update);
    io.to(mapId).emit('node:updated', maps[mapId].nodes[update.id]);
    saveMap(mapId);
  });

  socket.on('node:delete', ({id}) =>{
    const mapId = socket.data.mapId || 'default';
    delete maps[mapId].nodes[id];
    io.to(mapId).emit('node:deleted', { id });
    saveMap(mapId);
  });

  // Edge operations
  socket.on('edge:add', edge =>{
    const mapId = socket.data.mapId || 'default';
    const id = edge.id || uuidv4();
    const payload = Object.assign({}, edge, { id });
    maps[mapId].edges[id] = payload;
    io.to(mapId).emit('edge:added', payload);
    saveMap(mapId);
  });
  socket.on('edge:delete', ({id})=>{
    const mapId = socket.data.mapId || 'default';
    delete maps[mapId].edges[id];
    io.to(mapId).emit('edge:deleted', { id });
    saveMap(mapId);
  });

  socket.on('save:request', ()=>{
    const mapId = socket.data.mapId || 'default';
    saveMap(mapId);
    socket.emit('save:ok');
  });

  socket.on('disconnect', ()=>{
    const mapId = socket.data.mapId;
    if(mapId) socket.to(mapId).emit('user-left', { id: socket.id, name: socket.data.name });
    console.log('disc', socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, ()=> console.log('Server running on', PORT));
